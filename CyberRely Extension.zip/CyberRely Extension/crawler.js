function notify(text) {
	chrome.notifications.create(
  	"CyberRely PhishSafe",
  	{
    		type: "basic",
    		iconUrl: "CyberRely.png",
    		title: "CyberRely PhishSafe plugin",
    		message: text,
  	},
  	function () {}
	);
	window.close();
}

chrome.tabs.query({active: true, lastFocusedWindow: true}, tabs => {
    let url = tabs[0].url;
    let str = "http://xvalidate.herokuapp.com/site=" + url.toString().replaceAll("/", "&");
    console.log(str);
    fetch(str).then((response) => response.text()).then((text) => notify(text));
});
